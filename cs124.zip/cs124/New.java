import java.util.Scanner;
public class New{
public enum Day{
MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
public boolean isWeekend() {
return this==SATURDAY||this==SUNDAY;
}
public Day nextWorkingDay(){
switch(this){
case FRIDAY:
case SATURDAY:
case SUNDAY:
return MONDAY;
default:
return Day.values()[this.ordinal()+1];
}
}
}
public static void main(String[] args){
Scanner scanner=new Scanner(System.in);
System.out.println("enter the day of the week(eg.MONDAY): ");
String input=scanner.nextLine().trim().toUpperCase();
Day today;
try{
today=Day.valueOf(input);
}
catch(IllegalArgumentException e){
System.out.println("invalid day entered .Please enter a valid day of the week.");
return;
}
System.out.println("today is:"+today);
System.out.println("is today a weekend ?"+today.isWeekend());
System.out.println("next working day is:"+today.nextWorkingDay());
}
}


